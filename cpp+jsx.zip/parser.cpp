#include "parser.hpp"
#include <iostream>

token parser::current() {
    if (pos < tokens.size()) return tokens[pos];
    return {tokentype::eof, ""};
}
void parser::advance() { if (pos < tokens.size()) pos++; }
void parser::expect(tokentype type) {
    if (current().type == type) advance();
    else std::cerr << "unexpected token: '" << current().value << "'\n";
}

std::unique_ptr<expr> parser::parse_primary() {
    token t = current();

    // unary minus
    if (t.type == tokentype::op && t.value == "-") {
        advance();
        auto operand = parse_primary();
        return std::make_unique<multiply>(std::make_unique<number>(-1.0), std::move(operand));
    }

    // parenthesised group via braces
    if (t.type == tokentype::lbrace) {
        advance();
        auto e = parse_expr();
        expect(tokentype::rbrace);
        return e;
    }

    if (t.type == tokentype::number) {
        advance();
        return std::make_unique<number>(std::stod(t.value));
    }

    if (t.type == tokentype::variable) {
        advance();
        static const std::map<std::string,double> CONSTS = {
            {"pi", M_PI}, {"e", M_E},
            {"phi", (1+std::sqrt(5.0))/2}, {"tau", 2*M_PI}
        };
        if (CONSTS.count(t.value))
            return std::make_unique<named_constant>(t.value, CONSTS.at(t.value));
        return std::make_unique<variable>(t.value);
    }

    if (t.type == tokentype::command) {
        std::string cmd = t.value;
        advance();

        if (cmd == "\\int") {
            std::unique_ptr<expr> lower, upper;
            if (current().value == "_") {
                advance(); expect(tokentype::lbrace);
                lower = parse_expr(); expect(tokentype::rbrace);
                expect(tokentype::op);  // '^'
                expect(tokentype::lbrace);
                upper = parse_expr(); expect(tokentype::rbrace);
            }
            auto integrand = parse_expr();
            if (current().value == "d") advance();
            std::string v = current().value; advance();
            return std::make_unique<integral>(std::move(lower), std::move(upper), std::move(integrand), v);
        }

        if (cmd == "\\frac") {
            expect(tokentype::lbrace); auto n = parse_expr(); expect(tokentype::rbrace);
            expect(tokentype::lbrace); auto d = parse_expr(); expect(tokentype::rbrace);
            return std::make_unique<divide>(std::move(n), std::move(d));
        }

        if (cmd == "\\fact") {
            expect(tokentype::lbrace); auto a = parse_expr(); expect(tokentype::rbrace);
            return std::make_unique<factorial_node>(std::move(a));
        }

        if (cmd == "\\C" || cmd == "\\binom") {
            expect(tokentype::lbrace); auto n = parse_expr(); expect(tokentype::rbrace);
            expect(tokentype::lbrace); auto r = parse_expr(); expect(tokentype::rbrace);
            return std::make_unique<combination_node>(std::move(n), std::move(r));
        }

        if (cmd == "\\P") {
            expect(tokentype::lbrace); auto n = parse_expr(); expect(tokentype::rbrace);
            expect(tokentype::lbrace); auto r = parse_expr(); expect(tokentype::rbrace);
            return std::make_unique<permutation_node>(std::move(n), std::move(r));
        }

        if (cmd == "\\sum") {
            std::string idx = "i";
            std::unique_ptr<expr> from, to;
            if (current().value == "_") {
                advance(); expect(tokentype::lbrace);
                idx = current().value; advance();
                expect(tokentype::op);  // '='
                from = parse_expr(); expect(tokentype::rbrace);
                expect(tokentype::op);  // '^'
                expect(tokentype::lbrace); to = parse_expr(); expect(tokentype::rbrace);
            }
            return std::make_unique<sum_node>(idx, std::move(from), std::move(to), parse_primary());
        }

        if (cmd == "\\prod") {
            std::string idx = "i";
            std::unique_ptr<expr> from, to;
            if (current().value == "_") {
                advance(); expect(tokentype::lbrace);
                idx = current().value; advance();
                expect(tokentype::op);
                from = parse_expr(); expect(tokentype::rbrace);
                expect(tokentype::op);
                expect(tokentype::lbrace); to = parse_expr(); expect(tokentype::rbrace);
            }
            return std::make_unique<product_node>(idx, std::move(from), std::move(to), parse_primary());
        }

        // generic: \name{arg}
        expect(tokentype::lbrace);
        auto arg = parse_expr();
        expect(tokentype::rbrace);
        std::string fname = cmd.substr(1);
        if (fname == "abs") return std::make_unique<abs_node>(std::move(arg));
        return std::make_unique<func_call>(fname, std::move(arg));
    }

    return std::make_unique<number>(0.0);
}

std::unique_ptr<expr> parser::parse_factor() {
    auto base = parse_primary();
    while (current().value == "^") {
        advance();
        base = std::make_unique<pow_node>(std::move(base), parse_primary());
    }
    return base;
}

std::unique_ptr<expr> parser::parse_term() {
    auto left = parse_factor();
    while (current().value == "*") {
        advance();
        left = std::make_unique<multiply>(std::move(left), parse_factor());
    }
    return left;
}

std::unique_ptr<expr> parser::parse_expr() {
    auto left = parse_term();
    while (current().value == "+" || current().value == "-") {
        bool sub = current().value == "-";
        advance();
        auto right = parse_term();
        if (sub) right = std::make_unique<multiply>(std::make_unique<number>(-1.0), std::move(right));
        left = std::make_unique<add>(std::move(left), std::move(right));
    }
    return left;
}